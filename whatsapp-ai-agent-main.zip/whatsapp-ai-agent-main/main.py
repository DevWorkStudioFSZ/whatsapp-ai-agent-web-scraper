print("AI Agent Alive")
